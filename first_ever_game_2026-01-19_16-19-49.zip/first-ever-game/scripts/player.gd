extends CharacterBody2D

const SPEED = 125.0
const JUMP_VELOCITY = -300.0

@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var death_sound: AudioStreamPlayer2D = $death_sound

var music_index= AudioServer.get_bus_index("Music")
var dead = false

func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Handle jump.
	if Input.is_action_just_pressed("Jump") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# Gets the player direction (-1, 0, 1)
	var direction := Input.get_axis("move_left", "move_right")
	#flips player sprite to match direction
	if direction < 0:
		animated_sprite.flip_h = true
	elif direction > 0:
		animated_sprite.flip_h = false
		
	#Plays animations
	if not dead:
		if is_on_floor():
			if direction == 0:
				animated_sprite.play("idle")
			else:
				animated_sprite.play("run")
		else:
			animated_sprite.play("jump")
		
	#handles movement
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	move_and_slide()

#handles death
func _on_child_exiting_tree(node: Node2D) -> void:
	if node is CollisionShape2D:
		death_sound.play()
		print("lol you died")
		dead = true
		animated_sprite.play("death")
