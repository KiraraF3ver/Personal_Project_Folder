extends Node


var score = 0
@onready var ui_score_label: Label = %ui_score_label

func add_point():
	score += 1
	ui_score_label.text = "Score: " + str(score)
	print(score)
