extends Node2D

const SPEED = 60

@onready var ray_cast_right: RayCast2D = $RayCastRight
@onready var ray_cast_left: RayCast2D = $RayCastLeft
@onready var animatable_body: AnimatedSprite2D = $AnimatableBody2D

var direction = 1
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	
	if ray_cast_right.is_colliding():
		direction = -1
		animatable_body.flip_h = true
		
	elif ray_cast_left.is_colliding():
		direction = 1
		animatable_body.flip_h = false
		
	position.x += direction * delta * SPEED 
